package com.sunbeam.mobilesapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobilesappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobilesappApplication.class, args);
	}

}

