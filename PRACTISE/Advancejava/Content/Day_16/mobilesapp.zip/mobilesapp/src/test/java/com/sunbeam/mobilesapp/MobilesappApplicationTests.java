package com.sunbeam.mobilesapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobilesappApplicationTests {

	@Test
	void contextLoads() {
	}

}
